import Head from 'next/head'
export default function Dashboard(){
  return (
    <>
      <Head><title>Dashboard - MyAffiliatePro</title></Head>
      <main className="min-h-screen p-8">
        <h1 className="text-2xl font-bold">Dashboard (Admin)</h1>
        <p className="mt-4">This is your MVP dashboard. Users, credits, and basic analytics will appear here.</p>
      </main>
    </>
  )
}
