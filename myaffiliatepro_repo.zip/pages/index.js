import Head from 'next/head'
import { useState } from 'react'

export default function Home() {
  const [prompt, setPrompt] = useState('')
  const [result, setResult] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleGenerate(e) {
    e.preventDefault()
    setLoading(true)
    setResult('')
    const res = await fetch('/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt })
    })
    const data = await res.json()
    setLoading(false)
    setResult(data.output || data.error || 'No output')
  }

  return (
    <>
      <Head>
        <title>MyAffiliatePro — AI Affiliate Tools</title>
        <meta name="description" content="AI tools to build and monetize affiliate businesses." />
      </Head>
      <main className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="max-w-3xl w-full p-8">
          <h1 className="text-3xl font-bold mb-4">MyAffiliatePro — AI Pitch & Promo Generator</h1>
          <p className="mb-6">Type a short description of the product or business and get a pitch, ad copy, and affiliate angle.</p>
          <form onSubmit={handleGenerate} className="space-y-4">
            <textarea className="w-full p-3 border rounded" rows={4} value={prompt} onChange={(e)=>setPrompt(e.target.value)} placeholder="Describe the product or niche..." />
            <div>
              <button className="px-4 py-2 bg-blue-600 text-white rounded" disabled={loading}>{loading ? 'Generating...' : 'Generate'}</button>
            </div>
          </form>
          <div className="mt-6">
            <h2 className="text-xl font-semibold mb-2">Output</h2>
            <pre className="bg-white p-4 rounded border min-h-[120px]">{result}</pre>
          </div>
        </div>
      </main>
    </>
  )
}
