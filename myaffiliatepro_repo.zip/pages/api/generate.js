// Serverless API route for OpenAI generation (placeholder)
import OpenAI from 'openai'

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' })
  const { prompt } = req.body || {}
  if (!prompt) return res.status(400).json({ error: 'Missing prompt' })

  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'You are Pitch and affiliate marketing assistant.' },
        { role: 'user', content: `Create: 1) 2-sentence elevator pitch; 2) 3 ad headlines; 3) 1 affiliate angle for: ${prompt}` }
      ],
      max_tokens: 400,
    })
    const output = completion.choices?.[0]?.message?.content || ''
    res.status(200).json({ output })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'OpenAI request failed', details: String(err) })
  }
}
