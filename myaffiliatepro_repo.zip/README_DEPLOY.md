Quick Vercel deploy checklist:
- Create GitHub repo and push files.
- In Vercel, Import Project -> select repository.
- Add Environment Variables (see .env.example)
- Set up Stripe (Products / Prices) and add keys.
- Optionally add Firebase config and enable Email/Google sign-in.
